public class EmailListBuilderTester {

	// http://www.w3.org/People/Berners-Lee/card#i
	public static final String startURI = "http://danbri.org/foaf.rdf#danbri";
	
	public static void main(String[] args) {

		EmailAddressCollector eac = new EmailAddressCollector(startURI);
		eac.work();
		
		// here are all the collected email addresses
		eac.showemailAddresses();
		
	}
	
}