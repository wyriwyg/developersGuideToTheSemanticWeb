import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Stack;

public class URICollection {

	private Stack URIs = null;
	private HashSet visitedURIs = null;
	
	public URICollection() {
		URIs = new Stack();
		visitedURIs = new HashSet();
	}
	
	public void addNewURI(String uri) {
		if ( uri == null ) {
			return;
		}
		// testing purpose
		URI myURI = null;
		try {
			myURI = new URI(uri);
			if ( myURI.getHost().contains("my.opera.com") == true ) {
				return;
			}
			if ( myURI.getHost().contains("identi.ca") == true ) {
				return;
			}
			if ( myURI.getHost().contains("advogato.org") == true ) {
				return;
			}
			if ( myURI.getHost().contains("foaf.qdos.com") == true ) {
				return;
			}
			if ( myURI.getHost().contains("livejournal.com") == true ) {
				return;
			}
			if ( myURI.getHost().contains("openlinksw.com") == true ) {
				return;
			}
			if ( myURI.getHost().contains("rdf.opiumfield.com") == true ) {
				return;
			}
			if ( myURI.getHost().contains("ecademy.com") == true ) {
				return;
			}
			if ( myURI.getHost().contains("revyu.com") == true ) {
				return;
			}
			if ( myURI.getHost().contains("xircles.codehaus.org") == true ) {
				return;
			}
		} catch (URISyntaxException e1) {
			// e1.printStackTrace();
		}
		// end of testing purpose: you clean this part out to do more crawling

		try {
			if ( visitedURIs.contains(uri) == false ) {
				visitedURIs.add(uri);
				URIs.push(uri);
			}
		} catch(Exception e) {};
	}
	
	public String getNextURI() {
		if ( URIs.empty() == true ) {
			return null;
		}
		return (String)(URIs.pop());
	}
	
	public boolean isEmpty() {
		return URIs.isEmpty();
	}
	
	public void clearAll() {
		URIs.clear();
	}
	
	public void showAll() {
		if ( URIs.size() == 0 ) {
			System.out.println("none");
		}
		for ( int i = 0; i < URIs.size(); i ++ ) {
			System.out.println(URIs.elementAt(i).toString());
		}
	}
	
	public int getSize() {
		return URIs.size();
	}
	
	public void showVisitedURIs() {
		Iterator it = visitedURIs.iterator();
		while ( it.hasNext() ) {
			System.out.println(it.next().toString());
		}
	}
	
}

