import java.io.PrintWriter;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.sparql.vocabulary.FOAF;
import com.hp.hpl.jena.vocabulary.RDF;
import com.hp.hpl.jena.vocabulary.RDFS;

public class MyFOAFModel {
	
	public static void main(String[] args) {
		
		Model model = ModelFactory.createDefaultModel();
		model.setNsPrefix("rdfs",RDFS.getURI());
		model.setNsPrefix("foaf",FOAF.getURI());
				
		Resource subject = model.createResource("http://www.liyangyu.com/foaf.rdf#liyang");
		
		subject.addProperty(FOAF.name,"liyang yu");
		subject.addProperty(FOAF.title,"Dr");
		subject.addProperty(FOAF.givenname,"liyang");
		subject.addProperty(FOAF.family_name,"yu");
		subject.addProperty(FOAF.mbox,model.createResource("mailto:liyang@liyangyu.com"));
		subject.addProperty(FOAF.homepage,model.createResource("http://www.liyangyu.com"));
		subject.addProperty(FOAF.workplaceHomepage,model.createResource("http://www.delta.com"));
		subject.addProperty(FOAF.topic_interest,model.createResource("http://dbpedia.org/resource/Semantic_Web"));
		subject.addProperty(RDF.type,FOAF.Person);
		
		Resource blankSubject = model.createResource();
		blankSubject.addProperty(RDF.type,FOAF.Person);
		blankSubject.addProperty(FOAF.mbox,model.createResource("mailto:libby.miller@bristol.ac.uk"));
		blankSubject.addProperty(FOAF.homepage,model.createResource("http://www.ilrt.bris.ac.uk/~ecemm/"));
		subject.addProperty(FOAF.knows,blankSubject);
				
		model.write(new PrintWriter(System.out), "RDF/XML-ABBREV");
		// model.write(System.out);
	}

}