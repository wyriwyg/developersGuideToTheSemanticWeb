import java.util.Iterator;
import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.ontology.OntModelSpec;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.rdf.model.Statement;
import com.hp.hpl.jena.rdf.model.StmtIterator;
import com.hp.hpl.jena.reasoner.ValidityReport;
import com.hp.hpl.jena.util.FileManager;
import com.hp.hpl.jena.util.PrintUtil;

public class InfModelTester {
	
	public static final String RDF_FILE = "c:/liyang/myWebsite/currentPage/foaf.rdf";
	public static final String OWL_FILE = "http://xmlns.com/foaf/0.1/";
	
	public static void main( String[] args ) {
		
		// load instance data
		Model data = ModelFactory.createDefaultModel();
		FileManager.get().readModel(data,RDF_FILE);
		// use data.read() if reading from Web URL
		
		// create my ontology model
		OntModel ontModel = ModelFactory.createOntologyModel(OntModelSpec.RDFS_MEM_RDFS_INF,data);
		ontModel.read(OWL_FILE);
		
		// some validation to make us happy
		ValidityReport vr = ontModel.validate();
		if ( vr.isValid() == false ) {
			System.out.println("ontology model validation failed...");
	        for (Iterator i = vr.getReports(); i.hasNext(); ) {
	            System.out.println(" - " + i.next());
	        }
			return;
		}
				
		Resource yu = ontModel.getResource("http://www.liyangyu.com/foaf.rdf#yiding");
	    System.out.println("yu *:");
	    printStatements(ontModel, yu, null, null);
	    
	}
	
	private static void printStatements(Model m, Resource s, Property p, Resource o) {
		for (StmtIterator i = m.listStatements(s,p,o); i.hasNext(); ) {
            Statement stmt = i.nextStatement();
            System.out.println(" - " + PrintUtil.print(stmt));
        }
    }
}