import java.util.Iterator;
import com.hp.hpl.jena.rdf.model.InfModel;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.rdf.model.Statement;
import com.hp.hpl.jena.rdf.model.StmtIterator;
import com.hp.hpl.jena.reasoner.Reasoner;
import com.hp.hpl.jena.reasoner.ReasonerRegistry;
import com.hp.hpl.jena.reasoner.ValidityReport;
import com.hp.hpl.jena.util.FileManager;
import com.hp.hpl.jena.util.PrintUtil;
 
public class InfModelTester {
 	
   public static final String RDF_FILE = "c:/liyang/myWebsite/currentPage/foaf.rdf";
   public static final String OWL_FILE = "http://xmlns.com/foaf/0.1/";
 	
   public static void main( String[] args ) {
 		
     // load instance data
     Model data = ModelFactory.createDefaultModel();
     FileManager.get().readModel(data,RDF_FILE);
     // use data.read() if reading from Web URL
 		
     // load the ontology document
     Model ontology = ModelFactory.createDefaultModel();
     ontology.read(OWL_FILE);
 		
     // get the reasoner
     Reasoner owlReasoner = ReasonerRegistry.getOWLReasoner();
     owlReasoner = owlReasoner.bindSchema(ontology);
     
     // use the reasoner and instance data to create an inference model
     InfModel infModel = ModelFactory.createInfModel(owlReasoner,data);
 		
     // some validation to make us happy
     ValidityReport vr = infModel.validate();
     if ( vr.isValid() == false ) {
       System.out.print("ontology model validation failed.");
       for (Iterator i = vr.getReports(); i.hasNext(); ) {
         System.out.println(" - " + i.next());
       }
       return;
     }
 			
     Resource yu = infModel.getResource("http://www.liyangyu.com/foaf.rdf#yiding");
     System.out.println("yu *:");
     printStatements(infModel, yu, null, null);
    
   }
 	
   private static void printStatements(Model m,Resource s,Property p,Resource o) {
     for (StmtIterator i = m.listStatements(s,p,o); i.hasNext(); ) {
       Statement stmt = i.nextStatement();
       System.out.println(" - " + PrintUtil.print(stmt));
     }
   }

}
