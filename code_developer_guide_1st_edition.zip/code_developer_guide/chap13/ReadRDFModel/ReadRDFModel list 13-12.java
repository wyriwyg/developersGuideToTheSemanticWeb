import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.util.FileManager;
 
public class ReadRDFModel {
 	
   public static final String MY_FOAF_FILE = "http://liyangyu.com/foaf.rdf";
 
   public static void main( String[] args ) {
 
       Model model = ModelFactory.createDefaultModel();
       model.read(MY_FOAF_FILE);
       model.write(System.out,"N3");
   }

}
