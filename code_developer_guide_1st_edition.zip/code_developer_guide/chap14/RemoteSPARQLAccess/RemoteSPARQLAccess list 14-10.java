import com.hp.hpl.jena.query.Query;
import com.hp.hpl.jena.query.QueryExecution;
import com.hp.hpl.jena.query.QueryExecutionFactory;
import com.hp.hpl.jena.query.QueryFactory;
import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.rdf.model.Literal;
import com.hp.hpl.jena.rdf.model.RDFNode;
import com.hp.hpl.jena.rdf.model.Resource;

public class RemoteSPARQLAccess {

	final static String resourceURI = "http://dbpedia.org/resource/Roger_Federer";
	final static String DBpediaSPARQLEndpoint = "http://dbpedia.org/sparql";

	public static void main(String[] args) {

		String queryString = 
            "SELECT ?propertyName ?propertyValue " +
            "WHERE {" +
            "   <" + resourceURI + "> ?propertyName ?propertyValue." + 
            "}";
		
		Query query = QueryFactory.create(queryString);
		QueryExecution qe = QueryExecutionFactory.sparqlService(DBpediaSPARQLEndpoint,query);
		
		try {
			ResultSet results = qe.execSelect();
			while ( results.hasNext() ) {
				QuerySolution soln = results.nextSolution() ;
				Resource res = (Resource)(soln.get("propertyName"));
				System.out.print(" - <" + res.getURI() + "> : ");
			    RDFNode node = soln.get("propertyValue");
			    if ( node.isLiteral() ) {
			    	System.out.println( ((Literal)node).getLexicalForm());
			    } else if ( node.isResource() ) {
			    	res = (Resource)node;
			    	if ( res.isAnon() == true ) {
			    		System.out.println( "<" + res.getLocalName() + ">");
			    	} else {
			    		System.out.println( "<" + res.getURI() + ">");
			    	}
			    }
            }
        } 
		catch(Exception e) { 
			// doing nothing for now
		}
        finally {
        	qe.close();
        }
	}

}
