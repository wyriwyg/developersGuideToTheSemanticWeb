public class FollowYourNoseTester {

	// public static final String startURI = "http://dbpedia.org/resource/Roger_Federer";
	// http://dbpedia.org/page/Forrest_Gump
	// http://dbpedia.org/resource/Tim_Berners-Lee
	// http://dbpedia.org/resource/Semantic_Web
	// http://dbpedia.org/resource/Beijing
	// http://dbpedia.org/resource/Google
	// http://www.liyangyu.com/foaf.rdf#liyang
	public static final String startURI = "http://dbpedia.org/resource/Roger_Federer";
	
	public static void main(String[] args) {

		FollowYourNose fyn = new FollowYourNose(startURI);
		fyn.work();
		
	}
	
}
