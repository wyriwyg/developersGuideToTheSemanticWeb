import java.util.HashSet;
import java.util.Iterator;

import com.hp.hpl.jena.query.Query;
import com.hp.hpl.jena.query.QueryExecution;
import com.hp.hpl.jena.query.QueryExecutionFactory;
import com.hp.hpl.jena.query.QueryFactory;
import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.rdf.model.Literal;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.RDFNode;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.sparql.vocabulary.FOAF;
import com.hp.hpl.jena.vocabulary.RDFS;

public class EmailAddressCollector {

	private URICollection friendsToVisit = null;
	private HashSet emailAddresses = null;
	
	public EmailAddressCollector(String uri) {
		emailAddresses = new HashSet();
		friendsToVisit = new URICollection();
		friendsToVisit.addNewURI(uri);
	}
	
	public void work() {
		
		// get the next URI to work on (step 1 in algorithm)
		String currentURI = friendsToVisit.getNextURI();
		if ( currentURI == null ) {
			return;
		}
				
		try {
			System.out.println("\n...visiting <" + currentURI + ">");
			
			// dereference currentURI (step 1 in algorithm)		
			Model currentRDFDocument = ModelFactory.createDefaultModel();
			currentRDFDocument.read(currentURI);
		
			// collect everything about currentURI (step 2-4 in algorithm)
			int currentSize = friendsToVisit.getSize();
			collectData(currentRDFDocument,currentURI);
			System.out.println("..." + emailAddresses.size() + " email addresses collected.");
			System.out.println("..." + (friendsToVisit.getSize() - currentSize) + " new friends URI added.");
			System.out.println("...all together " + friendsToVisit.getSize() + " more to visit.");
			
		} catch (Exception e) {
			System.out.println("*** errors when handling (" + currentURI + ") ***");
		}

		// extend the social network by following friends of friends' (step 5 in algorithm)
		work();
		
	}

	private void collectData(Model model, String uri) {
		
		if ( uri == null ) {
			return;
		}
	
		String queryString =
		          "SELECT ?myself ?who ?email ?seeAlso " +
		          "WHERE {" +
		          "  ?myself <" + FOAF.knows + "> ?who. " + 
		          "  optional { ?who <" + FOAF.mbox + "> ?email. }" + 
		          "  optional { ?who <" + RDFS.seeAlso + "> ?seeAlso. }" +
		          "   }";


       /*
		String queryString =
			"SELECT ?who ?email ?seeAlso " +
			"WHERE {" +
			"  ?myself <" + FOAF.knows + "> ?who. " + 
			"  optional { ?who <" + FOAF.mbox + "> ?email. }" +
			"  optional { ?who <" + RDFS.seeAlso + "> ?seeAlso. }" +
			"   }"; */  

		Query query = QueryFactory.create(queryString);
		QueryExecution qe = QueryExecutionFactory.create(query,model);
		
		try {
			ResultSet results = qe.execSelect();
			while ( results.hasNext() ) {
				
				QuerySolution soln = results.nextSolution() ;
				Resource who = (Resource)(soln.get("who"));
				
				// step 2 in algorithm
				Resource email = (Resource)soln.get("email");
				if ( email != null ) {
					if ( email.isLiteral() ) {
						emailAddresses.add(((Literal)email).getLexicalForm());
					} else if ( email.isResource() ) {
						emailAddresses.add(email.getURI());
					}
				} else {
					// there is no foaf:mbox property value for this friend
				}
				
				// step 3 in algorithm
				if ( who.isAnon() == false ) {
					friendsToVisit.addNewURI(who.getURI());
				} else {
					// there is no URI specified for this friend
				}
				
				// step 3 in algorithm				
				Resource seeAlso = (Resource)soln.get("seeAlso");
				if ( seeAlso != null ) {
					if ( seeAlso.isLiteral() ) {
						friendsToVisit.addNewURI(((Literal)seeAlso).getLexicalForm());
					} else if ( seeAlso.isResource() ) {
						friendsToVisit.addNewURI(seeAlso.getURI());
					}
				} else {
					// there is no rdfs:seeAlso property value specified for this friend
				}	

			} 
        } 
		catch(Exception e) { 
			// doing nothing for now
		}
        finally {
        	qe.close();
        }
        
	}
		
	public void showemailAddresses() {
		if ( emailAddresses != null ) {
			Iterator it = emailAddresses.iterator();
			int counter = 1;
			while ( it.hasNext() ) {
				System.out.println(counter + ": " + it.next().toString());
				counter ++;
			}
		}
	}
	
}