import java.util.HashSet;
import java.util.Vector;

import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.ontology.OntModelSpec;
import com.hp.hpl.jena.query.Query;
import com.hp.hpl.jena.query.QueryExecution;
import com.hp.hpl.jena.query.QueryExecutionFactory;
import com.hp.hpl.jena.query.QueryFactory;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.query.ResultSetFormatter;
import com.hp.hpl.jena.rdf.model.InfModel;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.NsIterator;
import com.hp.hpl.jena.rdf.model.RDFNode;
import com.hp.hpl.jena.reasoner.Reasoner;
import com.hp.hpl.jena.reasoner.ReasonerRegistry;
import com.hp.hpl.jena.sparql.core.ResultBinding;
import com.hp.hpl.jena.util.FileManager;
import com.hp.hpl.jena.vocabulary.RDF;


public class MyShopBot {

	private static final String ontologyURL = "C:/liyang/myWritings/data/camera.owl";
	private static final String ontologyNS = "http://www.liyangyu.com/camera#";
	private static final String requestRdf = "C:/liyang/myWritings/data/myCameraDescription.rdf";
	private static final String catalog = "C:/liyang/myWritings/data/catalogExample1.rdf";
	private static final int MIN = 0;
	private static final int MAX = 1;
	
	private String targetItem = null;
	private String targetType = null;
	private Vector candidateItems = null;
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {

		MyShopBot myShopBot = new MyShopBot();
		myShopBot.work();
		
	}
	
	private void work() {
		
		// for the product we are looking for, get its URI and type info
		Model requestModel = getModel(requestRdf);
		if ( getItemToSearch(requestModel) == false ) {
			System.out.println("your request description is not complete!");
		}
		System.out.println("this URI describes the resource you are looking for:");
		System.out.println("<" + targetItem + ">");
		System.out.println("its type is given by the following class:");
		System.out.println("<" + targetType + ">");
		
		// find all the requested parameters
		
		CameraDescription myCamera = new CameraDescription();
		
		String targetPixel = getPixel(requestModel,targetItem);
		myCamera.setPixel(targetPixel);
		show("pixel(target)",targetPixel);
		
		String targetFocalLength = getFocalLength(requestModel,targetItem);
		myCamera.setFocalLength(targetFocalLength);
		show("focalLength(target)",targetFocalLength);
		
		String targetAperture = getAperture(requestModel,targetItem,MyShopBot.MIN);
		myCamera.setMinAperture(targetAperture);
		show("min aperture(target)",targetAperture);
		
		targetAperture = getAperture(requestModel,targetItem,MyShopBot.MAX);
		myCamera.setMaxAperture(targetAperture);
		show("max aperture(target)",targetAperture);
		
		String targetShutterSpeed = getShutterSpeed(requestModel,targetItem,MyShopBot.MIN);
		myCamera.setMinShutterSpeed(targetShutterSpeed);
		show("min shutterSpeed(target)",targetShutterSpeed);
		
		targetShutterSpeed = getShutterSpeed(requestModel,targetItem,MyShopBot.MAX);
		myCamera.setMaxShutterSpeed(targetShutterSpeed);
		show("max shutterSpeed(target)",targetShutterSpeed);
		
		CameraDescription currentCamera = new CameraDescription();
		while ( true ) {

			Model catalogModel = getModel(catalog);
			
			// see if it has potential candidates
			if ( isCandidate(catalogModel) == false ) {
				continue;
			}
			
			// create ontology model for inferencing
			OntModel ontModel =	ModelFactory.createOntologyModel(OntModelSpec.OWL_MEM_RULE_INF,catalogModel);
			FileManager.get().readModel(ontModel,ontologyURL);
			
			// which item could be it?
			candidateItems = findCandidateItem(ontModel);
			if ( candidateItems.size() == 0 ) {
				continue;
			}
			
			for ( int i = 0; i < candidateItems.size(); i ++ ) {
				
				String candidateItem = (String)(candidateItems.elementAt(i));
				System.out.println("\nFound a candidate: " + candidateItem);
				currentCamera.clearAll();
			
				// find the pixel value
				String pixel = getPixel(ontModel,candidateItem);
				currentCamera.setPixel(pixel);
				
				// find lens:focalLength value
				String focalLength = getFocalLength(ontModel,candidateItem);
				currentCamera.setFocalLength(focalLength);
				show("focalLength",focalLength);
			
				// find lens:aperture value
				String aperture = getAperture(ontModel,candidateItem,MyShopBot.MIN);
				currentCamera.setMinAperture(aperture);
				show("min aperture",aperture);
				aperture = getAperture(ontModel,candidateItem,MyShopBot.MAX);
				currentCamera.setMaxAperture(aperture);
				show("max aperture",aperture);
			
				// find body:shutterSpeed value
				String shutterSpeed = getShutterSpeed(ontModel,candidateItem,MyShopBot.MIN);
				currentCamera.setMinShutterSpeed(shutterSpeed);
				show("min shutterSpeed",shutterSpeed);
				shutterSpeed = getShutterSpeed(ontModel,candidateItem,MyShopBot.MAX);
				currentCamera.setMaxShutterSpeed(shutterSpeed);
				show("max shutterSpeed",shutterSpeed);
				
				if ( myCamera.sameAs(currentCamera) == true ) {
					System.out.println("found one match!");
				}
			}
				
			break;  // or next catalog file.
		}

	}

	private Vector findCandidateItem(Model m) {

		Vector candidates = new Vector();
		String queryString =  
		    "SELECT ?candidate " +
			"WHERE {" +
			"   ?candidate <" + RDF.type + "> <" + targetType + ">. " +
			"   }"; 
		
		Query q = QueryFactory.create(queryString);
		QueryExecution qe = QueryExecutionFactory.create(q,m);
		ResultSet rs = qe.execSelect();
		
		while ( rs.hasNext() ) {
			ResultBinding binding = (ResultBinding)rs.next();
			RDFNode rn = (RDFNode)binding.get("candidate");
			if ( rn != null && rn.isAnon() == false ) {
				candidates.add(rn.toString());
			} 
		}
		qe.close();
		return candidates;
	}

	private String getPixel(Model m, String itemURI) {
		
		String queryString =  
		    "SELECT ?value " +
			"WHERE {" +
			"   <" + itemURI + "> <http://www.liyangyu.com/camera#effectivePixel> ?value. " +
			"   }"; 
		
		Query q = QueryFactory.create(queryString);
		QueryExecution qe = QueryExecutionFactory.create(q,m);
		ResultSet rs = qe.execSelect();
		
		while ( rs.hasNext() ) {
			ResultBinding binding = (ResultBinding)rs.next();
			RDFNode rn = (RDFNode)binding.get("value");
			if ( rn != null && rn.isAnon() == false ) {
				return rn.toString();
			} 
		}
		qe.close();
		return null;
		
	}

	private String getFocalLength(Model m, String itemURI) {
		
		String queryString =  
		    "SELECT ?value " +
			"WHERE {" +
			"   <" + itemURI + "> <http://www.liyangyu.com/camera#lens> ?tmpValue. " +
			"   ?tmpValue <http://www.liyangyu.com/camera#focalLength> ?value . " +
			"   }"; 
		
		Query q = QueryFactory.create(queryString);
		QueryExecution qe = QueryExecutionFactory.create(q,m);
		ResultSet rs = qe.execSelect();
		
		while ( rs.hasNext() ) {
			ResultBinding binding = (ResultBinding)rs.next();
			RDFNode rn = (RDFNode)binding.get("value");
			if ( rn != null && rn.isAnon() == false ) {
				return rn.toString();
			} 
		}
		qe.close();
		return null;
		
	}
	
	private String getAperture(Model m, String itemURI, int minMaxFlag) {
		
		String queryString = null;
		if ( minMaxFlag == this.MIN ) {
			queryString = 
				"SELECT ?value " + 
				"WHERE {" +
				"   <" + itemURI + "> <http://www.liyangyu.com/camera#lens> ?tmpValue0. " +
				"   ?tmpValue0 <http://www.liyangyu.com/camera#aperture> ?tmpValue1 . " +
				"   ?tmpValue1 <http://www.liyangyu.com/camera#minValue> ?value . " +
				"   }"; 
		} else {
			queryString = 
				"SELECT ?value " + 
				"WHERE {" +
				"   <" + itemURI + "> <http://www.liyangyu.com/camera#lens> ?tmpValue0. " +
				"   ?tmpValue0 <http://www.liyangyu.com/camera#aperture> ?tmpValue1 . " +
				"   ?tmpValue1 <http://www.liyangyu.com/camera#maxValue> ?value . " +
				"   }";
		}
		    
		Query q = QueryFactory.create(queryString);
		QueryExecution qe = QueryExecutionFactory.create(q,m);
		ResultSet rs = qe.execSelect();
		
		String resultStr = "";
		while ( rs.hasNext() ) {
			ResultBinding binding = (ResultBinding)rs.next(); 
			RDFNode rn = (RDFNode)binding.get("value");
			if ( rn != null && rn.isAnon() == false ) {
				return rn.toString();
			} 
		}
		qe.close();
		return null;
		
	}
	
	private String getShutterSpeed(Model m, String itemURI, int minMaxFlag) {
		
		String queryString = null;
		if ( minMaxFlag == MyShopBot.MIN ) {
			queryString = 
				"SELECT ?value " + 
				"WHERE {" +
				"   <" + itemURI + "> <http://www.liyangyu.com/camera#body> ?tmpValue0. " +
				"   ?tmpValue0 <http://www.liyangyu.com/camera#shutterSpeed> ?tmpValue1 . " +
				"   ?tmpValue1 <http://www.liyangyu.com/camera#minValue> ?value . " +
				"   }"; 
		} else {
			queryString = 
				"SELECT ?value " + 
				"WHERE {" +
				"   <" + itemURI + "> <http://www.liyangyu.com/camera#body> ?tmpValue0. " +
				"   ?tmpValue0 <http://www.liyangyu.com/camera#shutterSpeed> ?tmpValue1 . " +
				"   ?tmpValue1 <http://www.liyangyu.com/camera#maxValue> ?value . " +
				"   }";
		}
		
		Query q = QueryFactory.create(queryString);
		QueryExecution qe = QueryExecutionFactory.create(q,m);
		ResultSet rs = qe.execSelect();
		
		String resultStr = "";
		while ( rs.hasNext() ) {
			ResultBinding binding = (ResultBinding)rs.next();
		    RDFNode rn = (RDFNode)binding.get("value");
			if ( rn != null && rn.isAnon() == false ) {
				return rn.toString();
			} 
		}
		qe.close();
		return null;
		
	}
	
	private boolean getItemToSearch(Model m) {
		
		String queryString =  
		    "SELECT ?subject ?predicate ?object " +
			"WHERE {" +
			"   ?subject <" + RDF.type + "> ?object. " + 
			"   }"; 

		Query q = QueryFactory.create(queryString);
		QueryExecution qe = QueryExecutionFactory.create(q,m);
		ResultSet rs = qe.execSelect();
		
		// collect the data type property names
		while ( rs.hasNext() ) {
			ResultBinding binding = (ResultBinding)rs.next();
			RDFNode rn = (RDFNode)binding.get("subject");
			if ( rn != null ) {
				targetItem = rn.toString();
			}
			rn = (RDFNode)binding.get("object");
			if ( rn != null ) {
				targetType = rn.toString();
			}
		}
		qe.close();
		
		if ( targetItem == null || targetItem.length() == 0 ) {
			return false;
		}
		if ( targetType == null || targetType.length() == 0 ) {
			return false;
		}
		return true;
	}

	// read in a given RDF document
	private Model getModel(String rdfURL) {
		
		Model m = null;
		if ( rdfURL == null ) return m;
		
		try {
			m = ModelFactory.createDefaultModel();
			FileManager.get().readModel(m,rdfURL);
			// m.read(rdfURL);
		} catch (Exception e) {
			System.out.println("====> error rading foaf file at [" + rdfURL + "]");
			m = null;
		}
		return m;
	}
	
	private boolean isCandidate(Model m) {
		
		if ( m == null  ) {
			return false;
		}
		
		HashSet ns = new HashSet();
		this.collectNamespaces(m,ns);
		return ns.contains(ontologyNS);
		
	}

	private void collectNamespaces(Model m,HashSet hs) {
		if ( hs == null || m == null ) {
			return;
		}
		NsIterator nsi = m.listNameSpaces();
		while ( nsi.hasNext() ) {
			hs.add(nsi.next().toString());
		}		
	}
	
	private void show(String t, String s) {
		if ( s != null && s.length() != 0 ) {
			System.out.println(t + " value is: " + s);
		} else {
			System.out.println(t + " value is not specified." );
		}
	}
	
}
