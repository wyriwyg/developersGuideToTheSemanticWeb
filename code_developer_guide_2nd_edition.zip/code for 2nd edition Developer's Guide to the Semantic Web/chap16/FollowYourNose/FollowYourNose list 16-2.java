import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.NodeIterator;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.RDFNode;
import com.hp.hpl.jena.rdf.model.ResIterator;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.rdf.model.Statement;
import com.hp.hpl.jena.rdf.model.StmtIterator;
import com.hp.hpl.jena.vocabulary.OWL;

public class FollowYourNose {

	private URICollection sameAsURIs = null;
	
	public FollowYourNose(String uri) {
		sameAsURIs = new URICollection();
		sameAsURIs.addNewURI(uri);
	}
	
	public void work() {
		
		// get the next link to follow
		String currentURI = sameAsURIs.getNextURI();
		if ( currentURI == null ) {
			return;
		}
		
		try {

			// de-reference this link		
			Model instanceDocument = ModelFactory.createDefaultModel();
			instanceDocument.read(currentURI);
		
			// do the data collection
			collectData(instanceDocument,currentURI);
			
			// find the next links to follow
			updateURICollection(sameAsURIs,currentURI,instanceDocument,OWL.sameAs);
			
		} catch (Exception e) {
			System.out.println("*** errors when handling (" + currentURI + ") ***");
		}
		
		System.out.println("\n---- these links are yet to follow ---- ");
		sameAsURIs.showAll();
		System.out.println("--------------------------------------- ");
		
		// following our nose
		work();
		
	}
	
	private void collectData(Model model, String uri) {
		if ( uri == null ) {
			return;
		}
		int factCounter = 0;
		System.out.println("Facts about <" + uri + ">:");
		for (StmtIterator si = model.listStatements(); si.hasNext(); ) {
            Statement statement = si.nextStatement();
            if ( uri.equalsIgnoreCase(statement.getSubject().getURI()) == true ) {
            	factCounter ++;
            	System.out.print(" - <" + statement.getPredicate().toString() + "> : <");
            	System.out.println(statement.getObject().toString() + ">");
            	if ( factCounter >= 10 ) {
            		return;
            	}
            }
        }
	}
	
	private void updateURICollection(URICollection uriCollection,String uri, 
			Model model,Property property) {
		if ( uri == null ) {
			return;
		}
		// check object
		Resource resource = model.getResource(uri);
		NodeIterator objects = model.listObjectsOfProperty(resource,property);
		while ( objects.hasNext() ) {
			RDFNode object = objects.next();
			if ( object.isResource() ) {
				Resource tmpResource = (Resource)object;
				uriCollection.addNewURI(tmpResource.getURI());
			}
		}
		// check the subject
		ResIterator subjects = model.listSubjectsWithProperty(property,resource);
		while ( subjects.hasNext() ) {
			Resource subject = subjects.nextResource();
			uriCollection.addNewURI(subject.getURI());
		}
	}
	
}
