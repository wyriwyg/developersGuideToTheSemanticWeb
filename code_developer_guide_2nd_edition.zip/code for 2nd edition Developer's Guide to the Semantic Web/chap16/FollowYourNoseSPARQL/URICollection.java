import java.net.URI;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Stack;

public class URICollection {

	private Stack URIs = null;
	private HashSet domainCollection = null;
	
	public URICollection() {
		URIs = new Stack();
		domainCollection = new HashSet();
	}
	
	public void addNewURI(String uri) {
		if ( uri == null ) {
			return;
		}
		try {
			URI thisURI = new URI(uri);
			if ( domainCollection.contains(thisURI.getHost()) == false ) {
				domainCollection.add(thisURI.getHost());
				URIs.push(uri);
			}
		} catch(Exception e) {};
	}
	
	public String getNextURI() {
		if ( URIs.empty() == true ) {
			return null;
		}
		return (String)(URIs.pop());
	}
	
	public void showAll() {
		for ( int i = 0; i < URIs.size(); i ++ ) {
			System.out.println(URIs.elementAt(i).toString());
		}
	}
	
}