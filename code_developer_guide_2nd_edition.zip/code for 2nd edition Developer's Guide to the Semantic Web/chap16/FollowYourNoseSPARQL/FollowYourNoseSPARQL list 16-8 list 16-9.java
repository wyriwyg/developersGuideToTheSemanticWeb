import com.hp.hpl.jena.query.Query;
import com.hp.hpl.jena.query.QueryExecution;
import com.hp.hpl.jena.query.QueryExecutionFactory;
import com.hp.hpl.jena.query.QueryFactory;
import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.rdf.model.Literal;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.NodeIterator;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.RDFNode;
import com.hp.hpl.jena.rdf.model.ResIterator;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.rdf.model.Statement;
import com.hp.hpl.jena.rdf.model.StmtIterator;
import com.hp.hpl.jena.vocabulary.OWL;

public class FollowYourNoseSPARQL {

	private URICollection sameAsURIs = null;
	
	public FollowYourNoseSPARQL(String uri) {
		sameAsURIs = new URICollection();
		sameAsURIs.addNewURI(uri);
	}
	
	public void work() {
		
		// get the next link to follow
		String currentURI = sameAsURIs.getNextURI();
		if ( currentURI == null ) {
			return;
		}
		
		try {

			// de-reference this link		
			Model instanceDocument = ModelFactory.createDefaultModel();
			instanceDocument.read(currentURI);
		
			// do the data collection
			collectData(instanceDocument,currentURI);
			
			// find the next links to follow
			updateURICollection(sameAsURIs,currentURI,instanceDocument,OWL.sameAs);
			
		} catch (Exception e) {
			System.out.println("*** errors when handling (" + currentURI + ") ***");
		}
		
		System.out.println("\n---- these links are yet to follow ---- ");
		sameAsURIs.showAll();
		System.out.println("--------------------------------------- ");
		
		// following our nose
		work();
		
	}
	
	private void collectData(Model model, String uri) {
		
		if ( uri == null ) {
			return;
		}
		
		int factCounter = 0;
		
		String queryString = 
            "SELECT ?propertyName ?propertyValue " +
            "WHERE {" +
            "   <" + uri + "> ?propertyName ?propertyValue." + 
            "}";

		Query query = QueryFactory.create(queryString);
		QueryExecution qe = QueryExecutionFactory.create(query,model);
		
		try {
			ResultSet results = qe.execSelect();
			while ( results.hasNext() ) {
				QuerySolution soln = results.nextSolution() ;
				factCounter ++;
				Resource res = (Resource)(soln.get("propertyName"));
				System.out.print(" - <" + res.getURI() + "> : ");
			    RDFNode node = soln.get("propertyValue");
			    if ( node.isLiteral() ) {
			    	System.out.println( ((Literal)node).getLexicalForm());
			    } else if ( node.isResource() ) {
			    	res = (Resource)node;
			    	if ( res.isAnon() == true ) {
			    		System.out.println( "<" + res.getLocalName() + ">");
			    	} else {
			    		System.out.println( "<" + res.getURI() + ">");
			    	}
			    }
			    if ( factCounter >= 10 ) {
            		break;
            	}
            }
        } 
		catch(Exception e) { 
			// doing nothing for now
		}
        finally {
        	qe.close();
        }
        
	}
	
	private void updateURICollection(URICollection uriCollection,String uri, 
			Model model,Property property) {
		if ( uri == null ) {
			return;
		}
		
		String queryString = 
            "SELECT ?aliasURI " +
            "WHERE {" +
            "  { <" + uri + "> <" + OWL.sameAs + "> ?aliasURI. } " +
            " union " + 
            "  { ?aliasURI <" + OWL.sameAs + "> <" + uri + ">. } " +
            "}";

		Query query = QueryFactory.create(queryString);
		QueryExecution qe = QueryExecutionFactory.create(query,model);
		
		try {
			ResultSet results = qe.execSelect();
			while ( results.hasNext() ) {
				QuerySolution soln = results.nextSolution() ;
				RDFNode node = soln.get("aliasURI");
			    if ( node.isResource() ) {
			    	Resource res = (Resource)node;
			    	if ( res.isAnon() == false ) {
			    		uriCollection.addNewURI(res.getURI());
			    	}
			    }
			}
        } 
		catch(Exception e) { 
			// doing nothing for now
		}
        finally {
        	qe.close();
        }
	}
	
}