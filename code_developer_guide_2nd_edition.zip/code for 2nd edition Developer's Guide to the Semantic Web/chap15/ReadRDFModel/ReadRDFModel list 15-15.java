import java.util.Iterator;
import java.util.Map;

import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.NodeIterator;
import com.hp.hpl.jena.rdf.model.RDFNode;
import com.hp.hpl.jena.rdf.model.ResIterator;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.rdf.model.Statement;
import com.hp.hpl.jena.rdf.model.StmtIterator;
import com.hp.hpl.jena.util.FileManager;
import com.hp.hpl.jena.vocabulary.OWL;
import com.hp.hpl.jena.vocabulary.RDF;

public class ReadRDFModel {
	
	public static final String RDF_FILE = "http://dbpedia.org/data/Roger_Federer.rdf";
	// public static final String RDF_FILE = "c:/liyang/myWebsite/currentPage/instancetype_en.rdf";
	
	public static void main( String[] args ) {
		
		Model model = ModelFactory.createDefaultModel();
		FileManager.get().readModel(model,RDF_FILE);
        // model.read(RDF_FILE);
		model.write(System.out,"N3");
		
		// show all the namespaces in the model
		Iterator prefixNsPairs = model.getNsPrefixMap().entrySet().iterator();
		while ( prefixNsPairs.hasNext() ) {
			Map.Entry entry = (Map.Entry)(prefixNsPairs.next());
			System.out.print("prefix:" + entry.getKey());
			System.out.println(", namespace:" + entry.getValue());
		}
		
		// show all the classes and their instances
		System.out.println("the following types/classes have been used in this RDF document (with their instances):");
		NodeIterator classes = model.listObjectsOfProperty(RDF.type);
		while ( classes.hasNext() ) {
			Resource typeRes = (Resource)(classes.next());
			System.out.println("(class/type) " + typeRes.getURI());
			ResIterator resources = model.listResourcesWithProperty(RDF.type,typeRes);
			while ( resources.hasNext() ) {
				Resource instanceRes = resources.nextResource();
				if ( instanceRes.isAnon() ) {
					System.out.println("  [anonymous instance] " + instanceRes.getId());
				} else {
					System.out.println("  [instance] " + instanceRes.getURI());
				}
			}
		}
		
		// show all the instances that have a owl:sameAs property
		System.out.println("\nthe following instance(s) has/have owl:sameAs property:");
		StmtIterator statements = model.listStatements((Resource)null,OWL.sameAs,(RDFNode)null);
		while ( statements.hasNext() ) {
			Statement statement = statements.nextStatement();
			Resource subject = statement.getSubject();
			if ( subject.isAnon() ) {
				System.out.print("  (" + subject.getId() + ")");
			} else {
				System.out.print("  (" + subject.getURI() + ")");
			}
			System.out.print(" OWL.sameAs ");
			Resource object = (Resource)(statement.getObject());
			if ( object.isAnon() ) {
				System.out.print("(" + object + ")");
			} else if ( object.isLiteral() ) {
				System.out.print("(" + object.toString() + ")");
			} else if ( object.isResource() ) {
				System.out.print("(" + object.getURI() + ")");
			}
			System.out.println();
		}
		
	}
}


