import com.hp.hpl.jena.datatypes.xsd.XSDDatatype;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.Resource;

public class HelloWorld {
	
	static private String nameSpace = "http://example.org/test/";
	
	public static void main(String[] args) {
		Model model = ModelFactory.createDefaultModel();
		
		model.setNsPrefix("test",nameSpace);
				
		Resource subject = model.createResource(nameSpace + "message");
		Property property = model.createProperty(nameSpace + "says");
		subject.addProperty(property,"Hello World!",XSDDatatype.XSDstring);
		
		model.write(System.out);
	}

}
