import com.hp.hpl.jena.db.DBConnection;
import com.hp.hpl.jena.db.IDBConnection;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.ModelMaker;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.rdf.model.Statement;
import com.hp.hpl.jena.rdf.model.StmtIterator;
import com.hp.hpl.jena.util.FileManager;
import com.hp.hpl.jena.util.PrintUtil;

public class DBModelTester {
	
	public static final String RDF_FILE = "http://www.liyangyu.com/foaf.rdf";
	public static final String ONTOLOGY_FILE = "http://xmlns.com/foaf/0.1/";
	
	private static String className = "com.mysql.jdbc.Driver";         
	private static String DB_URL = "jdbc:mysql://localhost:3306/myFoafModel";  
	private static String DB_USER = "root";                          
	private static String DB_PASSWD = "passwd";                      
	private static String DB_TYPE = "MySQL";                         
	private static String DOCUMENT_NAME = "myFoafRDF";
	private static String ONTOLOGY_NAME = "foaf.owl";

	public static void main( String[] args ) {
	
		IDBConnection conn = null;
		ModelMaker maker = null;
		
		try {
			Class.forName(className);
			conn = new DBConnection(DB_URL,DB_USER,DB_PASSWD,DB_TYPE);
		} catch (Exception e) { e.printStackTrace(); }
			
		maker = ModelFactory.createModelRDBMaker(conn);
		Model m = null;
		
		if ( !maker.hasModel(DOCUMENT_NAME) == true ) {
			System.out.println( "Loading instance document - one time only" );
			m = maker.createModel(DOCUMENT_NAME);
			FileManager.get().readModel(m,RDF_FILE);
		} else {
			m = maker.getModel(DOCUMENT_NAME);
		}
		printStatements(m, null, null, null);
		
		if ( !maker.hasModel(ONTOLOGY_NAME) ) {
			System.out.println( "Loading ontology document - one time only" );
			m = maker.createModel(ONTOLOGY_NAME);
			FileManager.get().readModel(m,ONTOLOGY_FILE);
		} else {
			m = maker.getModel(ONTOLOGY_NAME);
		}
		printStatements(m, null, null, null);

		try {
			conn.close();
		} catch(Exception e) { e.printStackTrace(); }
		
	}
	
	private static void printStatements(Model m, Resource s, Property p, Resource o) {
		for (StmtIterator i = m.listStatements(s,p,o); i.hasNext(); ) {
            Statement stmt = i.nextStatement();
            System.out.println(" - " + PrintUtil.print(stmt));
        }
    }
}