create table DB.DBA.PRODUCT (
  PRODUCT_ID VARCHAR(25),
  PRODUCT_DESCRIPTION VARCHAR(125),
  PRODUCT_CAT_ID INTEGER,
  PRODUCT_FORMAT_ID INTEGER,
  PRIMARY KEY (PRODUCT_ID)
  );

































