
insert into DB.DBA.PRODUCT values ( 'odbc-informix-ee', 'ODBC Drivers for Informix', 1, 4);
insert into DB.DBA.PRODUCT values ( 'odbc-informix-mt', 'ODBC Driver for Informix', 1, 3);
insert into DB.DBA.PRODUCT values ( 'odbc-informix-st', 'ODBC Driver for Informix', 1, 2);
insert into DB.DBA.PRODUCT values ( 'jdbc-ingres-mt', 'JDBC Driver for Ingres', 2, 3);
insert into DB.DBA.PRODUCT values ( 'oledb-odbc-st', 'OLE DB Provider for ODBC', 3, 2);
insert into DB.DBA.PRODUCT values ( 'dotnet-postgres-mt', '.NET Data Provider for PostgreSQL', 4, 3);

insert into DB.DBA.PRODUCT_CATEGORY values (1, 'ODBC Drivers');
insert into DB.DBA.PRODUCT_CATEGORY values (2, 'JDBC Drivers');
insert into DB.DBA.PRODUCT_CATEGORY values (3, 'OLEDB Data Providers');
insert into DB.DBA.PRODUCT_CATEGORY values (4, 'ADO.NET Data Providers');

insert into DB.DBA.PRODUCT_FORMAT values (1, 'Enterprise');
insert into DB.DBA.PRODUCT_FORMAT values (2, 'Single-Tier (Lite Edition)');
insert into DB.DBA.PRODUCT_FORMAT values (3, 'Multi-Tier (Enterprise Edition)');
insert into DB.DBA.PRODUCT_FORMAT values (4, 'Single-Tier (Express Edition)');

































